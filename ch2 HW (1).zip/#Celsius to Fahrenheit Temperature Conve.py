#Celsius to Fahrenheit Temperature Converter
#Abbie Ives
#1/14/2025

#Function to convert Celcius to Farenheit
def convert_temp(c_temp):
    f_temp=(9/5)*c_temp +32
    return f_temp

#Taking input for Clecius temp
c_temp = int(input("Enter in the temperature in degrees Celcius"))

#Set farenheit equal to function
f_temp = convert_temp(c_temp)

#print the converted temp in Farenheit
print("The temperature in Farenheit is:", f_temp)