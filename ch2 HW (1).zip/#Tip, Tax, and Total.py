#Tip, Tax, and Total
#Abbie Ives
#1/14/2025

#function to calculate the tip
def calculate_tip(meal_cost):
    tip = meal_cost * 0.18
    return tip

#function to calculate the tax
def calculate_tax(meal_cost):
    tax = meal_cost * 0.07
    return tax

#main program
meal_cost = float(input("Enter the cost of your meal: $"))

#calculate tip and tax
tip = calculate_tip(meal_cost)
tax = calculate_tax(meal_cost)
total = meal_cost + tip + tax

#print the results, making sure the numbers are displayed with 2 decimal places
print(f"Tip (18%): ${tip:.2f}")
print(f"Tax (7%): ${tax:.2f}")
print(f"Total amount: ${total:.2f}")
